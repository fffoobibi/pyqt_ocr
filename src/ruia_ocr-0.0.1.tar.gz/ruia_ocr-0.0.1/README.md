# ruia_ocr 

This is a simple plugin for ruia, You can upload local pictures or web images for ocr service

