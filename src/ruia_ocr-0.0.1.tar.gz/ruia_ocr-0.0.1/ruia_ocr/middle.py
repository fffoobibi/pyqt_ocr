import asyncio
import typing

from ruia import Middleware, Spider, Request
from ruia.utils import get_logger
from .service import BaseOcrService, BaiduOcrService
from .configs import (BAIDU_ACCURATE_PAYLOAD, BAIDU_GENERAL_PAYLOAD, BAIDU_GENERALBASIC_PAYLOAD,
                      BAIDU_ACCURATEBASIC_PAYLOAD, BAIDU_ACCURATE_TYPE, BAIDU_ACCURATEBASIC_TYPE,
                      BAIDU_GENERAL_TYPE, BAIDU_GENERALBASIC_TYPE)

__all__ = ['ocr_middle', 'monkey_patch_ruia']

DEFAULT_OPTIONS = {'payloads': BAIDU_ACCURATEBASIC_PAYLOAD,
                   'fail_images': [],
                   'image_hook_kwargs': {},
                   'region': ''}

service_type_dic = {BAIDU_ACCURATEBASIC_TYPE: BAIDU_ACCURATEBASIC_PAYLOAD,
                    BAIDU_ACCURATE_TYPE: BAIDU_ACCURATE_PAYLOAD,
                    BAIDU_GENERALBASIC_TYPE: BAIDU_GENERALBASIC_PAYLOAD,
                    BAIDU_GENERAL_TYPE: BAIDU_GENERAL_PAYLOAD}

ocr_middle = Middleware()

logger = get_logger('Spider')
logger_ocr = get_logger('Ocr')


@classmethod
def extension_start(cls,
                    middleware: typing.Union[typing.Iterable, Middleware] = None,
                    loop=None, after_start=None,
                    before_stop=None,
                    close_event_loop=True,
                    **kwargs) -> Spider:
    try:
        loop = loop or asyncio.new_event_loop()
        spider_ins = cls(middleware=middleware, loop=loop, **kwargs)
        spider_ins.loop.run_until_complete(
            spider_ins._start(after_start=after_start, before_stop=before_stop)
        )
        spider_ins.loop.run_until_complete(spider_ins.loop.shutdown_asyncgens())
        if close_event_loop:
            spider_ins.loop.close()
    except asyncio.CancelledError:
        pass
    finally:
        return spider_ins


@classmethod
async def extension_async_start(cls,
                                middleware: typing.Union[typing.Iterable, Middleware] = None,
                                loop=None,
                                after_start=None,
                                before_stop=None,
                                cancel_tasks: bool = True,
                                **kwargs) -> Spider:
    try:
        loop = loop or asyncio.get_event_loop()
        spider_ins = cls(
            middleware=middleware,
            loop=loop,
            is_async_start=True,
            cancel_tasks=cancel_tasks,
            **kwargs
        )
        await spider_ins._start(after_start=after_start, before_stop=before_stop)
    except asyncio.CancelledError:
        pass
    finally:
        return spider_ins


async def extension_make_request(self):
    """Make a request by using aiohttp"""
    self.logger.info(f"<{self.method}: {self.ocr_url if self.ocr_url else self.url}>")
    if self.method == "GET":
        request_func = self.current_request_session.get(
            self.url, headers=self.headers, ssl=self.ssl, **self.aiohttp_kwargs
        )
    else:
        request_func = self.current_request_session.post(
            self.url, headers=self.headers, ssl=self.ssl, **self.aiohttp_kwargs
        )
    resp = await request_func
    return resp


def monkey_patch_ruia() -> None:
    # logger_ocr.info('Ruia\'s Spider monkey patch installed by ruia_ocr')
    # logger_ocr.info('Ruia\'s Request monkey patch installed by ruia_ocr')
    Spider.start = extension_start
    Spider.async_start = extension_async_start
    Request._make_request = extension_make_request


async def _service_check(spider_ins) -> bool:
    if getattr(spider_ins, 'ocr_service', None):
        spider_ins._tmp_ocr_service = spider_ins.ocr_service
        return True
    else:
        for key, attr in spider_ins.__class__.__dict__.items():
            if isinstance(attr, BaseOcrService):
                spider_ins._tmp_ocr_service = attr
                return True
        else:
            return False


async def _ocr_payload(spider_ins) -> None:
    ocr_service:BaiduOcrService = spider_ins.ocr_service
    if getattr(spider_ins, 'ocr_options', None):
        if spider_ins.ocr_options.get('payloads', None):
            if ocr_service._service_type in service_type_dic.keys():
                payloads = service_type_dic.get(ocr_service._service_type)
                payloads.update(spider_ins.ocr_options['payloads'])
                ocr_service._service_payload = payloads
            else:
                ocr_service._service_payload = spider_ins.ocr_options['payloads']
        else:
            if ocr_service._service_type in service_type_dic.keys():
                payloads = service_type_dic.get(ocr_service._service_type)
                spider_ins.ocr_options['payloads'] = payloads
                ocr_service._service_payload = payloads
            else:
                ocr_service._register_payload = False
        ocr_service._register_payload = True

    else:
        options = DEFAULT_OPTIONS.copy()
        if ocr_service._service_type in service_type_dic.keys():
            options['payloads'].update(service_type_dic.get(ocr_service._service_type))
            ocr_service._service_payload = options
            ocr_service._register_payload = True
        else:
            ocr_service._register_payload = False


async def _stop_spider(spider_ins, request) -> None:
    spider_ins.failed_counts = len(spider_ins.start_urls)
    request.retry_times = 0
    logger.error('Your spider does not find the ocr-service object. It will be stop right away!')
    tasks = []
    for task in asyncio.Task.all_tasks(loop=spider_ins.loop):
        task.cancel()
        tasks.append(task)
    try:
        await asyncio.wait(tasks)
    except asyncio.CancelledError:
        pass


@ocr_middle.request
async def request_ocr_service(spider_ins, request):
    if await _service_check(spider_ins):
        await _ocr_payload(spider_ins)
        await spider_ins._tmp_ocr_service.service_middle_request(request, spider_ins)
    else:
        await _stop_spider(spider_ins, request)


@ocr_middle.response
async def response_ocr_service(spider_ins, reqeust, response):
    try:
        ocr = getattr(spider_ins, '_tmp_ocr_service')
        await ocr.service_middle_response(reqeust, response, spider_ins)
    except:
        logger.warning('Baidu-ocr service_type may does not support the ocr_payloads you submit,'
                       'please check it. See more details at https://ai.baidu.com/docs#/OCR-API-Access/top')
