from .exceptions import *
from .service import *
from .exceptions import *
from .middle import *
from .utils import *
from .items import *
from .configs import *

name = 'ruia_ocr'
monkey_patch_ruia()
