import os
import base64
import hmac
import hashlib
import datetime
import requests

from PIL import Image
from io import BytesIO
from asyncio import Semaphore
from inspect import isawaitable
from urllib.parse import urlparse, quote, urlencode

from ruia import Request
from ruia.utils import get_logger
from .exceptions import ServicePayloadsError, ImageTypeError
from .configs import *

service_type_dic = {
    BAIDU_ACCURATEBASIC_TYPE: BAIDU_ACCURATEBASIC_PAYLOAD,
    BAIDU_ACCURATE_TYPE: BAIDU_ACCURATE_PAYLOAD,
    BAIDU_GENERALBASIC_TYPE: BAIDU_GENERALBASIC_PAYLOAD,
    BAIDU_GENERAL_TYPE: BAIDU_GENERAL_PAYLOAD
}
logger = get_logger('Spider')

try:
    # Adaptive interface changes. It's recommended to do this
    from aip.base import AipBase

    _access_token_url = AipBase._AipBase__accessTokenUrl
except:
    # Fixed api implementation, not recommended
    _access_token_url = 'https://aip.baidubce.com/oauth/2.0/token'

__all__ = ['BaiduOcrService', 'BaseOcrService']


def getAuthrHeaders(method,
                    url,
                    params=None,
                    headers=None,
                    _apiKey=None,
                    _secretKey=None):
    headers = headers or {}
    params = params or {}

    urlResult = urlparse(url)
    for kv in urlResult.query.strip().split('&'):
        if kv:
            k, v = kv.split('=')
            params[k] = v

    # UTC timestamp
    timestamp = datetime.datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    headers['Host'] = urlResult.hostname
    headers['x-bce-date'] = timestamp
    version, expire = '1', '1800'

    # 1 Generate SigningKey
    val = "bce-auth-v%s/%s/%s/%s" % (version, _apiKey, timestamp, expire)
    signingKey = hmac.new(_secretKey.encode('utf-8'), val.encode('utf-8'),
                          hashlib.sha256).hexdigest()

    # 2 Generate CanonicalRequest
    # 2.1 Genrate CanonicalURI
    canonicalUri = quote(urlResult.path)
    # 2.2 Generate CanonicalURI: not used here
    # 2.3 Generate CanonicalHeaders: only include host here

    canonicalHeaders = []
    for header, val in headers.items():
        canonicalHeaders.append(
            '%s:%s' %
            (quote(header.strip(), '').lower(), quote(val.strip(), '')))
    canonicalHeaders = '\n'.join(sorted(canonicalHeaders))

    # 2.4 Generate CanonicalRequest
    canonicalRequest = '%s\n%s\n%s\n%s' % (
        method.upper(), canonicalUri, '&'.join(
            sorted(urlencode(params).split('&'))), canonicalHeaders)

    # 3 Generate Final Signature
    signature = hmac.new(signingKey.encode('utf-8'),
                         canonicalRequest.encode('utf-8'),
                         hashlib.sha256).hexdigest()

    headers['authorization'] = 'bce-auth-v%s/%s/%s/%s/%s/%s' % (
        version, _apiKey, timestamp, expire, ';'.join(
            headers.keys()).lower(), signature)

    return headers


class BaseOcrService(object):
    '''
    You can implement your own ocr-services by only implementing a subclass.
    Service url and service type and service data are one-to-one corresponding
    method service_middle_request is executing during middle.request
    method service_middle_response is executing during middle.response
    You can rewrite both methods to customize your own ocr-service
    name: ocr-service 's name
    service_types: This is a list(List[str]) of all service types that contain the interfaces defined by you, and you should implement it in a subclass
    '''

    name = 'BaseOcrService'
    service_types = None

    def __init__(self):
        self._service_url = None
        self._service_type = None
        self._service_payload = None

    def register_payload(self, *args, **kwargs):
        raise NotImplementedError

    def service_payload(self, *args, **kwargs):
        raise NotImplementedError

    def service_type(self, *args, **kwargs):
        raise NotImplementedError

    def service_url(self, *args, **kwargs):
        raise NotImplementedError

    async def hook_func(self, request, spider_ins):
        pass

    async def _localImage_or_webImage_parse(self, request: Request,
                                            spider_ins) -> dict:
        pass

    async def request_process(self, request: Request, spider_ins):
        '''
        The action of the real modification request before the request is sent
        :param request: Request
        '''
        raise NotImplementedError

    async def service_middle_request(self, request: Request,
                                     spider_ins) -> None:
        '''
        It's going to execute at the middleware.request level.
        Initialize your service based on your service-type and the image-data(image_path or image_url) which you provided
        This method will configure a correct data format to send your request to ocr-service providers before your service is actually sent out.
        :param request: ruia.Request
        :param loop: spider_ins.loop
        '''
        res = self.hook_func(request, spider_ins)
        if isawaitable(res):
            await res
        image_data = self._localImage_or_webImage_parse(request, spider_ins)
        if isawaitable(image_data):
            await image_data
        _ = self.request_process(request, spider_ins)
        if isawaitable(_):
            await _

    async def service_middle_response(self, request, response,
                                      spider_ins) -> None:
        '''
        It's going to execute at the middleware.response level.
        You could implement it in a subclass to customize your behavior during the middle.response's period
        :param request: Request
        :param response: Response
        :param loop: None
        :return:
        '''
        pass


class BaiduOcrService(BaseOcrService):
    '''
    Built-in configuration parameters for 2 services, GENERALBASIC and GENERAL.
    If you need to use baidu-ocr extra services, configure the parameters to match by use method register_payload

    '''
    name = "Baidu-Ocr"
    service_types = [
        service_type for key, service_type in baidu_ocr_types.items()
    ]
    access_token_url = _access_token_url

    def __init__(self,
                 app_id,
                 api_key,
                 secret_key,
                 service_type=BAIDU_GENERALBASIC_TYPE,
                 seq=''):
        '''
        :param app_id: your app_id, See more at https://ai.baidu.com/docs#/OCR-API/top
        :param api_key: your api_key, See more at https://ai.baidu.com/docs#/OCR-API/top
        :param secret_key: your secret_key, See more at https://ai.baidu.com/docs#/OCR-API/top
        :param service_type: your request service type, There are a total of 41 service types,
        See more at https://ai.baidu.com/docs#/OCR-API/top
        '''

        super().__init__()
        self.app_id = app_id
        self.api_key = api_key
        self.seq = seq
        self.secret_key = secret_key
        self._service_type = service_type
        self._service_url = None
        self._service_payload = service_type_dic.get(service_type, {})
        self._register_payload = False
        if service_type not in self.service_types:
            raise ServicePayloadsError(
                'Baidu-Ocr service must in %s \n See more details at '
                'https://ai.baidu.com/docs#/OCR-API/top' % self.service_types)

        try:
            # Adaptive interface changes. It's recommended to do this
            from aip import AipOcr
            _ocr = AipOcr(app_id, api_key, secret_key)
            _authobj = _ocr._auth()
            _version = _ocr.getVersion()
            self._access_token = _ocr._auth().get('access_token')
            self._params = _ocr._getParams(_authobj)
            self._params.update(aipSdk='python', aipVersion=_version)
        except:
            # Fixed api implementation, not recommended
            self._access_token = None
            self._params = {
                'access_token': self._access_token,
                'aipSdk': 'python'
            }
        finally:
            self._access_token_semphone = None
            headers = getAuthrHeaders('POST',
                                      self.service_url,
                                      _apiKey=self.api_key,
                                      _secretKey=self.secret_key)
            headers.update(
                {'Content-Type': 'application/x-www-form-urlencoded'})
            self._headers = headers

    def register_payload(self, payloads: dict) -> None:
        '''
        :param payloads: The parameters of the service you requested,is a python dict

        '''
        self._service_payload = payloads
        self._register_payload = True

    @property
    def service_url(self):
        '''
        :return:  Return the servicse url of your task requirements
        '''
        if self._service_url is None:
            self._service_url = baidu_ocr_urls.get(self.service_type[:-4] +
                                                   'URL')
        return self._service_url

    @property
    def service_type(self):
        '''
        :return:  Return your service type
        '''
        return self._service_type

    @property
    def service_payload(self):
        '''
        :return: Return the parameters that your service needs to send
        '''
        if not self._register_payload:
            raise ValueError(
                'Should register baidu-ocr payload by use method register_payload,'
                'See more details at https://ai.baidu.com/docs#/OCR-API/top')
        return self._service_payload

    async def _get_access_token(self):
        '''
        baidu-ocr service need access_token, this method try to get this parameter.
        :return: access_token
        '''
        if self._access_token is None:
            response = await Request(url=self.access_token_url,
                                     params={
                                         'grant_type': 'client_credentials',
                                         'client_id': self.api_key,
                                         'client_secret': self.secret_key
                                     }).fetch()
            json = await response.json()
            self._access_token, self._expires_in = json.get(
                'access_token'), json.get('expires_in')
        return self._access_token

    async def hook_func(self, request, spider_ins):
        if self._access_token_semphone is None:
            self._access_token_semphone = Semaphore(1, loop=spider_ins.loop)
        if self._access_token is None:
            async with self._access_token_semphone:
                await self._get_access_token()

    async def get_ocr_image_hook(self, image, region: '1,1,200,200'):
        if region:
            # Stitching pictures
            boxs = []
            for v in region.strip(';').split(';'):
                box = list((map(float, v.split(','))))
                for index, coord in enumerate(box):
                    if index % 2 == 0:
                        if coord < 1:
                            box[index] = image.width * coord
                    else:
                        if coord < 1:
                            box[index] = image.height * coord
                box = list(map(int, box))
                boxs.append(box)
            imgs = [image.crop(box) for box in boxs]
            width, height = list(zip(*[img.size for img in imgs]))
            max_width = max(width)
            img_new = Image.new('RGB', (max_width, sum(height)))
            for index, img in enumerate(imgs):
                box = (0, sum(height[:index]), img.width,
                       sum(height[:index + 1]))
                img_new.paste(img, box)
            # img_new.show()
            return img_new
        else:
            return image

    async def get_ocr_image(self, file_path, request, spider_ins, hook,
                            region):
        _image = Image.open(file_path)
        if hook:
            _image = hook(_image, region)
            if isawaitable(_image):
                _image = await _image
        _max = max(_image.height, _image.width)
        _min = min(_image.height, _image.width)
        if _max > 4096:
            request.retry_times = 0
            logger.error(
                'Baidu-ocr \'s longest edge of the picture can not exceed 4096 px'
            )
            raise ImageTypeError
        if _min < 15:
            request.retry_times = 0
            logger.error(
                'Baidu-ocr \'s shortest edge of the picture cannot be less than 15 px'
            )
            raise ImageTypeError

        image_io = BytesIO()
        _image.save(image_io, format='PNG')
        return base64.b64encode(image_io.getvalue()).decode(), file_path

    async def _localImage_or_webImage_parse(self, request: Request,
                                            spider_ins):
        '''
        process image-data(loacl-image or web-image) during middle.request
        :param request: Request
        '''
        _raw_url = request.url
        if _raw_url.startswith('https'):
            logger.error('Baidu-ocr does not support remote https image link,'
                         'check your start_urls')
            request.retry_times = 0
            raise ImageTypeError
        elif _raw_url.startswith('http'):
            # self._service_payload.update(url=_raw_url)
            self._service_payload.pop('image', None)
            self._service_payload.update(url=_raw_url)
        else:
            if _raw_url[-3:].lower() not in ['jpg', 'png', 'bmp', 'peg']:
                logger.error('Baidu does not support this type of picture , '
                             'must be `jpg`, `png`, `bmp` or `jpeg`')
                request.retry_times = 0
                request._ok = False
                raise ImageTypeError
            else:
                image, _path = await self.get_ocr_image(
                    _raw_url,
                    request,
                    spider_ins,
                    hook=self.get_ocr_image_hook,
                    region=spider_ins.ocr_options['region'])
                self._service_payload.pop('url', None)
                self._service_payload.update(image=image)

    async def request_process(self, request, spider_ins):
        # Baidu ocr's request header parameters
        # headers = getAuthrHeaders('POST', self.service_url, _apiKey=self.api_key,
        #                           _secretKey=self.secret_key)
        # headers.update({'Content-Type': 'application/x-www-form-urlencoded'})
        request.metadata = {'image': os.path.basename(request.url)}
        request.ocr_url = request.url
        request.url = self.service_url
        request.method = 'POST'
        request.headers = self._headers
        aiohttp_kwargs = request.aiohttp_kwargs
        aiohttp_kwargs.pop('params', None)
        aiohttp_kwargs.pop('data', None)
        aiohttp_kwargs.update(params=self._params)
        aiohttp_kwargs.update(data=self._service_payload.copy())
        request.aiohttp_kwargs = aiohttp_kwargs

    async def service_middle_response(self, request, response, spider_ins):
        # Baidu ocr returns a json value
        json = await response.json()
        words_result = json.get('words_result', None)
        res = []
        if isinstance(words_result, list):
            if words_result:
                for dic in words_result:
                    res.append(dic.get('words'))
                response.ocr_html = self.seq.join(res)
            else:
                response.ocr_html = ''
        else:
            # failed request
            response._ok = False
            response.ocr_html = ''
            spider_ins.ocr_options['failed_images'].append(
                os.path.basename(request.ocr_url))
            logger.warning(f'{request.ocr_url} failed')
            logger.error('Reason:' + str(json))

    def request(self, image_path=None, region=None, *, img=None):
        self._register_payload = True
        if img is None:
            if image_path[-3:].lower() not in ['jpg', 'png', 'bmp', 'peg']:
                logger.error('Baidu does not support this type of picture , '
                            'must be `jpg`, `png`, `bmp` or `jpeg`')
                raise ImageTypeError
            image = Image.open(image_path)
        else:
            image = img

        if region:
            boxs = []
            for v in region.strip(';').split(';'):
                box = list((map(float, v.split(','))))
                for index, coord in enumerate(box):
                    if index % 2 == 0:
                        if coord < 1:
                            box[index] = image.width * coord
                    else:
                        if coord < 1:
                            box[index] = image.height * coord
                box = list(map(int, box))
                boxs.append(box)
            imgs = [image.crop(box) for box in boxs]
            width, height = list(zip(*[img.size for img in imgs]))
            max_width = max(width)
            img_new = Image.new('RGB', (max_width, sum(height)))
            for index, img in enumerate(imgs):
                box = (0, sum(height[:index]), img.width,
                       sum(height[:index + 1]))
                img_new.paste(img, box)
            image = img_new

        image_io = BytesIO()
        image.save(image_io, format='PNG')
        b64_data = base64.b64encode(image_io.getvalue()).decode()
        payloads = self.service_payload.copy()
        payloads.update({'image': b64_data})
        json = requests.post(url=self.service_url,
                             headers=self._headers,
                             params=self._params,
                             data=payloads).json()
        return json

    def __repr__(self):
        return f'{self.name}<{self.service_url}, {self.service_type}>'
