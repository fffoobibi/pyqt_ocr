class ImageTypeError(Exception):
    pass


class ServicePayloadsError(Exception):
    pass


class OcrServiceNotFoundError(Exception):
    pass
