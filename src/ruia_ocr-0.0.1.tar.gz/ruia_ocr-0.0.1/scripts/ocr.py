import re
import os
import logging
import click

from typing import List
from configparser import ConfigParser
from openpyxl import Workbook
from ruia.utils import get_logger
from ruia import Item, Spider
from ruia_ocr import (OcrField, ocr_middle, BaiduOcrService, get_file_paths, BAIDU_ACCURATEBASIC_TYPE,
                      BAIDU_GENERAL_TYPE, BAIDU_GENERALBASIC_TYPE, BAIDU_ACCURATE_TYPE)

type_dic = {'1': BAIDU_GENERAL_TYPE, '2': BAIDU_GENERALBASIC_TYPE,
           '3': BAIDU_ACCURATE_TYPE, '4': BAIDU_ACCURATEBASIC_TYPE}


class FuncBuilder(object):
    def __init__(self, indent=4):
        self._indent = indent
        self.indent_content = ' ' * self._indent
        self.codes = []

    def addline(self, st):
        self.codes.append(st + '\n')

    def indent(self):
        self.codes[-1] = self.codes[-1] + self.indent_content

    def compile(self, gl={}):
        exec(''.join(self.codes), gl)

    def str_codes(self) -> str:
        return ''.join(self.codes)

    def __repr__(self):
        return ''.join(self.codes)


def compile(pats: str, prefix='async def clean_', args='(self, st):', temp_var='st') -> FuncBuilder:
    def _comple(st: str):
        res = st.split('+')
        if len(res) == 1:
            data = res[0]
            if data.startswith('slice'):
                res[0] = f'st[{data}]'
            elif data.endswith(')'):
                res[0] = f'st.{data}'
            elif data.endswith("'"):
                res[0] = f'{data}'
            elif not data.endswith(')'):
                res[0] = f'st.{data}()'
            return res
        else:
            return _comple(res[0]) + ['+'] + _comple('+'.join(res[1:]))

    values = []
    coder = FuncBuilder()
    for func in pats.split(';'):
        res = re.split('(\|)|(.*?=)', func)
        res = list(filter(lambda e: e not in ['|', '', None], res))
        tmp = []
        tmp.append(res[0][:-1])  # func name
        for index, v in enumerate(res):
            if index != 0:
                codes = _comple(v)
                tmp.append(''.join(codes))
        values.append(tmp)

    for codes in values:
        coder.addline(prefix + codes[0] + args)
        for index, code in enumerate(codes):
            if index != 0:
                coder.indent()
                coder.addline(temp_var + '=' + code)
        coder.indent()
        coder.addline('return ' + temp_var)
    return coder


def adapter_item(pattern, pattern_clean):
    def parse(cls):
        cls.collect = []
        fields = pattern.strip(';').split(';')
        for field in fields:
            name, pat = field.split('=')
            cls.collect.append(name)
            getattr(cls, '__fields').update({name: OcrField(re_select=pat, re_flags=re.DOTALL, default='NotFound')})
        funcs_space = {}
        coder = compile(pattern_clean)
        coder.compile(funcs_space)
        for func in funcs_space.keys():
            if func.startswith('clean'):
                setattr(cls, func, funcs_space[func])
        return cls

    return parse


def adapter_spider(range):
    def parse(cls):
        cls.ocr_options['region'] = range
        return cls

    return parse


def parse_path(path: str) -> str:
    if path.startswith('desktop'):
        path = path.replace('desktop', '~\\Desktop', 1)
        path = os.path.expanduser(path)
    elif path.startswith('~'):
        path = path.replace('~', os.path.expanduser('~'), 1)
    return path


@click.command()
@click.option('-s', '--settings', type=str, help='app_id=xxx;api_key=xxx;secret_key=xxx')
@click.option('-i', '--images', type=str, help='image or image dirs', required=True)
@click.option('-o', '--out', type=str,
              help='output file,txt or xlsx,`desktop\\result.txt` mean `~\\Desktop\\result.txt`')
@click.option('-h', '--header', type=str,
              help='If the output is an xlsx file, it is set to the header,write as `title1,title2`')
@click.option('-t', '--type', type=click.Choice(list('1234')), default='4',
              help='1: BAIDU_GENERAL_TYPE, 2: BAIDU_GENERALBASIC_TYPE,'
                   '3: BAIDU_ACCURATE_TYPE,4: BAIDU_ACCURATEBASIC_TYPE , default `4`')
@click.option('-p', '--pattern', type=str, help='Define item fields,default `text=.*`', default='text=.*')
@click.option('-p-c', '--pattern-clean', type=str,
              help='Set up a cleaning function for item, '
                   'Support for string \'s lower, upper, strip, replace, zfill, etc. and pipe operation by use `|`',
              default='text=strip')
@click.option('-n', '--number', type=int, default=-1, help='Limit the number of pictures,default `-1` mean all picture')
@click.option('-d', '--debug', is_flag=True, type=bool, default=False, help='Debug default `False`')
@click.option('-c', '--coordinate', type=str, help='box 0,0,210,210;')
@click.option('-l', '--lag', type=float, default=0.5)
def make(settings, images, out, header, type, pattern, pattern_clean, number, debug, coordinate, lag):
    cp = ConfigParser()
    logger = get_logger('Results')

    if settings:
        cp.add_section('baiduocr')
        file = open(os.path.join(os.path.expanduser('~'), 'ruia_ocr.cfg'), 'w+')
        configs = settings.split(';').split(';')
        for setting in configs:
            key, v = setting.split('=')
            cp.set('baiduocr', key, v)
        cp.write(file)
        file.close()
    else:
        cp.read(os.path.join(os.path.expanduser('~'), 'ruia_ocr.cfg'))

    service = BaiduOcrService(cp.get('baiduocr', 'app_id'),
                              cp.get('baiduocr', 'api_key'),
                              cp.get('baiduocr', 'secret_key'),
                              type_dic.get(type),
                              seq='\n')

    imgs = parse_path(images)

    if not debug:
        logging.root.setLevel(logging.FATAL)
    if number == -1:
        urls = get_file_paths(imgs) if os.path.isdir(imgs) else [imgs]
    else:
        urls = get_file_paths(imgs, num=int(number)) if os.path.isdir(imgs) else [imgs]

    @adapter_item(pattern=pattern, pattern_clean=pattern_clean)
    class OcrItem(Item):
        pass

    @adapter_spider(range=coordinate)
    class OcrSpider(Spider):
        ocr_service = service
        ocr_options = {'region': ''}

        start_urls = urls
        concurrency = 1
        request_config = {'TIMEOUT': 40, 'DELAY': lag}
        dump_res: List[List[str]] = []

        async def parse(self, response):
            item = await OcrItem.get_item(html=response.ocr_html)
            item.path = os.path.basename(response.metadata.get('image'))
            yield item

        async def process_item(self, item: Item):
            dumps = [getattr(item, attr) for attr in OcrItem.collect]
            dumps.insert(0, item.path)
            self.dump_res.append(dumps)

    spider = OcrSpider.start(middleware=ocr_middle)
    logging.root.setLevel(logging.DEBUG)

    for res in spider.dump_res:
        if debug:
            logger.info(res[0] + ': ' + ' || '.join(res[1:]))
        else:
            click.echo(res[0] + ': ' + ' || '.join(res[1:]))

    if out:
        parsed_out = parse_path(out)
        if out.endswith('txt'):
            with open(parsed_out, 'w+', encoding='utf8') as file:
                contents = [pic_contents[1:] for pic_contents in spider.dump_res]
                for content in contents:
                    file.write('\n'.join(content) + '\n')

        elif out.endswith('xlsx'):
            wk = Workbook()
            sh = wk.active
            if header:
                spider.dump_res.insert(0, ['picture'] + header.split(','))
            for res in spider.dump_res:
                sh.append(res)
            wk.save(parsed_out)
        if debug:
            logger.info('save as %s' % os.path.abspath(out))
        else:
            click.echo('save as %s' % os.path.abspath(out))


if __name__ == '__main__':
    make()